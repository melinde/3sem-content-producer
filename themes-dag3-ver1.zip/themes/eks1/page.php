<?php get_header(); ?>

            <div class="col-lg-12">
              <?php
              if ( have_posts() ) :

                // Start the Loop.
                while ( have_posts() ) :
                  the_post();
                  ?>
                  <article>
                    <h1><?php the_title(); ?></h1>
                    <hr>

                      <?php the_post_thumbnail('banner-img'); ?>
                     <hr>
                      <?php the_content(); ?>
                    <hr>
                  </article>
                  <?php

                endwhile;


              else :
                ?>
                <p>Vi fandt desværre ingen poster</p>
              <?php
              endif;
              ?>


            </div>



        <hr>
<?php get_footer(); ?>
