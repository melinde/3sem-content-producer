

<h1>Dette er mit helt eget custom theme</h1>

<?php
function minFunktion(){
  echo 2+2;
}?>

<h2><?php echo minFunktion(); ?></h2>
