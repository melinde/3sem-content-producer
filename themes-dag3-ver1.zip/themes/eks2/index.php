<?php get_header(); ?>
  <div class="main">
      <div class="container">
      <?php
        if(have_posts()) :
          while(have_posts()) : the_post();?>
          <h3><?php the_title(); ?></h3>
          <div class="meta">
          Skrevet af <?php the_author();?> den <?php the_date('d-m-Y');?>
          </div>
          <?php
          the_content();
          endwhile;

          else :

          echo wpautop('beklager men der blev ikke fundet nogen poster');

        endif;?>
      </div>
    </div>
    <?php get_footer(); ?>
