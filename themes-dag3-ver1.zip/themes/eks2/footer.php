<footer>
  <div class="container">
  <p>&copy; <?php the_time('Y'); ?></p>

</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
