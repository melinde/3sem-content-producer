<footer>
    <div class="row">
        <div class="col-lg-12">
            <p>Copyright &copy; Merete</p>
        </div>
    </div>
</footer>

</div>
<?php wp_footer(); ?>
</body>
</html>
