<?php get_header(); ?>
            <nav>
             <ul>
              <li><a href="#home">Hjem</a></li>
              <li><a href="#news">Nyheder</a></li>
              <li><a href="#contact">Kontakt</a></li>
              <li><a href="#about">Om os</a></li>
             </ul>
            </nav>
           </div>
            <div class="col-lg-8">



              <?php
        			if ( have_posts() ) :

        				// Start the Loop.
        				while ( have_posts() ) :
        					the_post();
                  ?>
                  <article>
                    <a href="<?php the_permalink(); ?>"><h1><?php the_title(); ?></h1></a>
                    <hr>

                      <p>Skrevet af <?php the_author(); ?> den <?php the_date('d-m-Y'); ?> under <?php the_category(', '); ?></p>


                     <?php the_post_thumbnail('banner-img'); ?>
                     <hr>
                      <?php the_content(); ?>
                    <hr>
                  </article>
                  <?php
        				endwhile;

        			else :
                ?>
        				<p>Vi fandt desværre ingen poster</p>
                <?php
        			endif;
        			?>


            </div>

            <div class="col-md-4">
                 <?php if(dynamic_sidebar('right_sidebar')) : else : endif  ?>
            </div>

        </div>

        <hr>
<?php get_footer(); ?>
