<?php
function akademi_filer(){
  wp_enqueue_style('akademi_main_style', get_stylesheet_uri() );
}
add_action(wp_enqueue_scripts, 'akademi_filer');
