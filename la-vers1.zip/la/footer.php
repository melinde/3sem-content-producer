<footer>
<p>copyright &copy; Merete </p>


</footer>
<?php wp_footer(); ?>

</body>
</html>
