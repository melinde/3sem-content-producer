<?php get_header();
if ( have_posts() ) :

  // Start the Loop.
  while ( have_posts() ) :
    the_post();
    ?>
    <article>
      <a href="<?php the_permalink(); ?>"><h1><?php the_title(); ?></h1></a>
      <hr>

       <p>Skrevet af <?php the_author(); ?> den <?php the_time('d-m-Y'); ?> under <?php the_category(', '); ?></p>


       <hr>
        <?php the_content(); ?>
      <hr>
    </article>
    <?php

  endwhile;


else :
  ?>
  <p>Vi fandt desværre ingen poster</p>
<?php
endif;
?>

<?php get_footer(); ?>
