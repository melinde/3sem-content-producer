<?php get_header(); ?>

    <div class="col-lg-12">
      <h1>Velkommen til MLI Design</h1>
            </div>
      <?php the_post_thumbnail('banner-img'); ?>


        <hr>
<?php get_footer(); ?>
