<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<div class="container">

        <div class="row">

          <div class="col-lg-12">
            <header>
              <?php the_custom_logo(); ?>
              <div class="website-title"><a href="<?php bloginfo('url');?>"><?php bloginfo('name'); ?></a></div>
              <span class="tagline"><?php bloginfo('description'); ?></span>
            </header>
            <nav>
            <?php
            $args = array(
              'theme_location' => 'top_nav'
            );
            wp_nav_menu();

             ?>
            </nav>
  </div>
