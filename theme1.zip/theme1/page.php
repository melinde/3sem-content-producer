<?php get_header(); ?>
            <nav>
             <ul>
              <li><a href="#home">Hjem</a></li>
              <li><a href="#news">Nyheder</a></li>
              <li><a href="#contact">Kontakt</a></li>
              <li><a href="#about">Om os</a></li>
             </ul>
            </nav>
           </div>
            <div class="col-lg-12">



              <?php
        			if ( have_posts() ) :

        				// Start the Loop.
        				while ( have_posts() ) :
        					the_post();
                  ?>
                  <article>
                    <h1><?php the_title(); ?></h1>
                    <hr>

                     <img class="img-responsive" src="http://placehold.it/900x300" alt="" >
                     <hr>
                      <?php the_content(); ?>
                    <hr>
                  </article>
                  <?php
        				endwhile;

        			else :
                ?>
        				<p>Vi fandt desværre ingen poster</p>
                <?php
        			endif;
        			?>


            </div>



        </div>

        <hr>
<?php get_footer(); ?>
