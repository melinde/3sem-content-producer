<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="bootstrap.min.css" rel="stylesheet" >
    <link href="style.css" rel="stylesheet" >
</head>
<body>

<div class="container">

        <div class="row">

          <div class="col-lg-12">
            <header>
              <div class="website-title">Keep It Simple!</div>
              <span class="tagline">Her indsættes tagline...</span>
            </header>
            <nav>
             <ul>
              <li><a href="#home">Hjem</a></li>
              <li><a href="#news">Nyheder</a></li>
              <li><a href="#contact">Kontakt</a></li>
              <li><a href="#about">Om os</a></li>
             </ul>
            </nav>
           </div>
            <div class="col-lg-8">
                <article>
                  <a href="#"><h1>Blog Post Title 1</h1></a>
                  <hr>

                   <p><span class="glypticon gkypticon-time"></span> Publiceret: August 24, 2013 at 9:00 PM</p>

                   <img class="img-responsive" src="http://placehold.it/900x300" alt="" >
                   <hr>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ut, tenetur natus doloremque laborum quos iste ipsum rerum obcaecati impedit odit illo dolorum ab tempora nihil dicta earum fugiat. Temporibus, voluptatibus.</p>

                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos, doloribus, dolorem iusto blanditiis unde eius illum consequuntur neque dicta incidunt ullam ea hic porro optio ratione repellat perspiciatis. Enim, iure!</p>

                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Error, nostrum, aliquid, animi, ut quas placeat totam sunt tempora commodi nihil ullam alias modi dicta saepe minima ab quo voluptatem obcaecati?</p>

                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Harum, dolor quis. Sunt, ut, explicabo, aliquam tenetur ratione tempore quidem voluptates cupiditate voluptas illo saepe quaerat numquam recusandae? Qui, necessitatibus, est!</p>

                  <hr>
                </article>

                 <article>
                  <a href="#"><h1>Blog Post Title 2</h1></a>
                  <hr>

                   <p><span class="glypticon gkypticon-time"></span> Publiceret: August 24, 2013 at 9:00 PM</p>

                   <img class="img-responsive" src="http://placehold.it/900x300" alt="" >
                   <hr>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ut, tenetur natus doloremque laborum quos iste ipsum rerum obcaecati impedit odit illo dolorum ab tempora nihil dicta earum fugiat. Temporibus, voluptatibus.</p>

                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos, doloribus, dolorem iusto blanditiis unde eius illum consequuntur neque dicta incidunt ullam ea hic porro optio ratione repellat perspiciatis. Enim, iure!</p>

                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Error, nostrum, aliquid, animi, ut quas placeat totam sunt tempora commodi nihil ullam alias modi dicta saepe minima ab quo voluptatem obcaecati?</p>

                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Harum, dolor quis. Sunt, ut, explicabo, aliquam tenetur ratione tempore quidem voluptates cupiditate voluptas illo saepe quaerat numquam recusandae? Qui, necessitatibus, est!</p>

                  <hr>
                </article>

            </div>

            <div class="col-md-4">
                 <h3>Kategori widget</h3>
                            <ul>
                                <li><a href="#">Kategori Navn</a>
                                </li>
                                <li><a href="#">Kategori Navn</a>
                                </li>
                                <li><a href="#">Kategori Navn</a>
                                </li>
                                <li><a href="#">Kategori Navn</a>
                                </li>
                            </ul>

                    <h3>Tekst Widget</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore, perspiciatis adipisci accusamus laudantium odit aliquam repellat tempore quos aspernatur vero.</p>

            </div>

        </div>

        <hr>
<footer>
    <div class="row">
        <div class="col-lg-12">
            <p>Copyright &copy; Thomas</p>
        </div>
    </div>
</footer>

</div>
</body>
</html>
