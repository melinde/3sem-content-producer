<?php
function simple_add_styles(){
  wp_enqueue_style('style', get_stylesheet_uri());
  wp_enqueue_style('bootstrap', get_template_directory_uri() . '/css/bootstrap.min.css');
}
add_action('wp_enqueue_scripts', 'simple_add_styles');

function simple_theme_support(){
  add_theme_support('title-tag');
  add_theme_support('post-thumbnails');
  add_image_size('banner-img', 900, 300, true);

}
add_action('after_setup_theme','simple_theme_support' );

register_nav_menus(array(
  'top_nav' => __('Top navigation')
));
 ?>
