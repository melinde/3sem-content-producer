<?php get_header(); ?>
            <nav>
             <?php
             $args = array(
               'theme-location' => 'top-nav'
             );
             wp_nav_menu($args);
              ?>
            </nav>
           </div>
            <div class="col-lg-8">



              <?php
        			if ( have_posts() ) :

        				// Start the Loop.
        				while ( have_posts() ) :
        					the_post();
                  ?>
                  <article>
                    <a href="<?php the_permalink(); ?>"><h1><?php the_title(); ?></h1></a>
                    <hr>

                    <p>Skrevet af <?php the_author(); ?> den <?php the_date('d-m-Y'); ?> under <?php the_category(', '); ?></p>


                     <?php the_post_thumbnail(); ?>
                     <hr>
                      <?php the_content(); ?>
                    <hr>
                  </article>
                  <?php
        				endwhile;

        			else :
                ?>
        				<p>Vi fandt desværre ingen poster</p>
                <?php
        			endif;
        			?>


            </div>

            <div class="col-md-4">
                 <h3>Kategori widget</h3>
                            <ul>
                                <li><a href="#">Kategori Navn</a>
                                </li>
                                <li><a href="#">Kategori Navn</a>
                                </li>
                                <li><a href="#">Kategori Navn</a>
                                </li>
                                <li><a href="#">Kategori Navn</a>
                                </li>
                            </ul>

                    <h3>Tekst Widget</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore, perspiciatis adipisci accusamus laudantium odit aliquam repellat tempore quos aspernatur vero.</p>

            </div>

        </div>

        <hr>
<?php get_footer(); ?>
